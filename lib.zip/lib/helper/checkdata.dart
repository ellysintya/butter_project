// import 'package:sqflite/sqflite.dart';
// import 'package:path/path.dart';
// import 'package:butter_project/data%20base/data_service.dart';

// class Helper {
//   static final Helper dataHelper = Helper._init();
//   static Database? database;

//   Helper._init();

//   Future<Map<String, dynamic>?> fetchData(String nama) async {
//     final db = await dataHelper.database;
//   }
// }
