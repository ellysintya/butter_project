class Daftar_Menu {
  String nama ;
  int harga ;
  String gambar ;

  Daftar_Menu({
    required this.nama , required this.harga , required this.gambar

});
}

List<Daftar_Menu> daftarMenu = [
  Daftar_Menu(
      nama: "Bakmie + Bakso Bakwan Fiyen",
      harga: 33000,
      gambar: "https://i.gojekapi.com/darkroom/gofood-indonesia/v2/images/uploads/983d3d3f-e0c2-4cab-a425-e922c4d5e9a9_Go-Biz_20220417_171918.jpeg?auto=format"),
  Daftar_Menu(
      nama: "Bakmie + Pangsit",
      harga: 26000,
      gambar: "https://i.gojekapi.com/darkroom/gofood-indonesia/v2/images/uploads/2e9c46c7-614e-41e0-9c7f-5a88377b3a2b_Go-Biz_20220510_140539.jpeg?auto=format"),
  Daftar_Menu(
      nama: "Bakmie + Bakso Campur",
      harga: 33000,
      gambar: " "),

  Daftar_Menu(
      nama: "Bakmie LTM ",
      harga: 21000,
      gambar: "https://i.gojekapi.com/darkroom/gofood-indonesia/v2/images/uploads/eb829dd3-9a93-4b28-9650-e7250e102f97_Go-Biz_20220417_171818.jpeg?auto=format"),
  Daftar_Menu(
      nama: "Ifumie Goreng LTM",
      harga: 48000,
      gambar: "https://i.gojekapi.com/darkroom/gofood-indonesia/v2/images/uploads/2c224f07-43c2-4cec-98a0-d2fb54fa91ce_Go-Biz_20240320_181541.jpeg?auto=format")

];