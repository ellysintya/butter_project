class MdKaryawan {
  int? id;
  String nama;
  String pass;
  int no_telp;
  String email;

  MdKaryawan(
      {this.id,
      required this.nama,
      required this.pass,
      required this.no_telp,
      required this.email});
}
