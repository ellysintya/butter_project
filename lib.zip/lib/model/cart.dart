import 'package:butter_app_project/model/product_models.dart';

class Cart {
  ProductModel? product;
  int? quantity;

  Cart({required this.product, required this.quantity});
}
