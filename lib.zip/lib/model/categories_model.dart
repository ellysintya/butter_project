
class Category {
  String name;

  Category({required this.name});
}

List<Category> categories = [
  Category(name: 'All Menu'),
  Category(name: 'Paket Lion Tahu Metal'),
  Category(name: 'Paket Bakmie / Pangsit LTM'),
  Category(name: 'Paket Soup Bakso LTM'),
  Category(name: 'Paket Hupia / Fish Cake'),
  Category(name: 'Seasonal Menu'),
  Category(name: 'Juice'),
  Category(name: 'Frozen Pack'),
  Category(name: 'Minuman'),
  Category(name: 'Dessert LTM'),
];
